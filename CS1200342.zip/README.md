# COL216 Computer Architecture
## Lab Assignment 2, Stage 4: Support for all DP opcodes

This stage does not require any additional hardware design, assuming  that the ALU designed in stage 1 already supports all DP opcodes. Therefore, the task at this  stage is simply to test the design of stage 3 extensively, covering all DP instructions.